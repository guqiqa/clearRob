#!/bin/bash
# deploy_fixes.sh — rebuild and restart Phase 1 with all fixes
set -e
pkill -9 -f ros2 2>/dev/null || true
sleep 1
cd /root/cleaning_robot_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select remote_driver chassis_driver cleaning_robot_bringup --symlink-install
source install/setup.bash
rm -f /tmp/phase1_fixed.log
nohup ros2 launch cleaning_robot_bringup phase1_chassis.launch.py simulate:=false > /tmp/phase1_fixed.log 2>&1 &
echo "deployed — pid=$!"
sleep 6
echo "=== STATUS ==="
grep -E "started|STANDBY|Auto-calibrat|ERROR|died" /tmp/phase1_fixed.log | head -10
grep "Auto-calibrat" /tmp/phase1_fixed.log
